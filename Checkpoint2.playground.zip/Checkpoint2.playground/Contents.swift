// Zheen H. Suseyi
// 09/21/24

/*
 This time the challenge is to create an array of strings, then write some code that prints the number of items in the array and also the number of unique items in the array.
 */

import UIKit

// defining our initial variables
var counter = 0
// array of strings
let greetings = ["Hi", "Hello", "Whats Up", "Hey", "Yo", "Hi"]
// iterating thru our array of strings so that it prints all of them out along with a counter that will count the number of items in the array
for _ in greetings {
    print(greetings)
    counter+=1
}
// print the number of items in the array
print(counter)
// assigning uniqueGreetings to the greetings set in order to filter out any duplicates
var uniqueGreetings = Set(greetings)
// printing out the number of uniques items in the array without using a for loop this time
print(uniqueGreetings.count)
